"use client";
import React from "react";

import { useUpload } from "../utilities/runtime-helpers";

function MainComponent() {
  const [selectedWorkout, setSelectedWorkout] = useState("A");
  const [isRunning, setIsRunning] = useState(false);
  const [time, setTime] = useState(0);
  const [distance, setDistance] = useState(0);
  const [activeTab, setActiveTab] = useState("workout");
  const [editingExercise, setEditingExercise] = useState(null);
  const [editingProfile, setEditingProfile] = useState(false);
  const [profile, setProfile] = useState({
    name: "José Victor",
    age: "24",
    height: "165",
    weight: "52",
    goal: "Ganho de massa muscular",
    level: "Intermediário",
    photo:
      "https://ucarecdn.com/f0f31afb-4837-45df-afd5-38f10f5fdc3d/-/format/auto/",
  });
  const [workouts, setWorkouts] = useState({
    A: [
      {
        exercise: "Supino Reto",
        sets: "4",
        reps: "12",
        weight: "0",
        completed: false,
      },
      {
        exercise: "Puxada Frontal",
        sets: "4",
        reps: "12",
        weight: "0",
        completed: false,
      },
      {
        exercise: "Desenvolvimento",
        sets: "3",
        reps: "12",
        weight: "0",
        completed: false,
      },
    ],
    B: [
      {
        exercise: "Agachamento",
        sets: "4",
        reps: "12",
        weight: "0",
        completed: false,
      },
      {
        exercise: "Leg Press",
        sets: "4",
        reps: "12",
        weight: "0",
        completed: false,
      },
      {
        exercise: "Extensora",
        sets: "3",
        reps: "12",
        weight: "0",
        completed: false,
      },
    ],
    C: [
      {
        exercise: "Rosca Direta",
        sets: "4",
        reps: "12",
        weight: "0",
        completed: false,
      },
      {
        exercise: "Tríceps Corda",
        sets: "4",
        reps: "12",
        weight: "0",
        completed: false,
      },
      {
        exercise: "Elevação Lateral",
        sets: "3",
        reps: "12",
        weight: "0",
        completed: false,
      },
    ],
    D: [
      {
        exercise: "Corrida",
        sets: "1",
        reps: "30min",
        weight: "0",
        completed: false,
      },
      {
        exercise: "Abdominais",
        sets: "4",
        reps: "20",
        weight: "0",
        completed: false,
      },
      {
        exercise: "Prancha",
        sets: "3",
        reps: "1min",
        weight: "0",
        completed: false,
      },
    ],
  });
  const [measurements, setMeasurements] = useState({
    peso: "",
    altura: "",
    gordura: "",
    muscular: "",
    historico: [],
  });
  const [editingMeal, setEditingMeal] = useState(null);
  const [meals, setMeals] = useState({
    cafeDaManha: {
      title: "Café da Manhã",
      time: "7:00",
      items: [
        "2 ovos + 1 fatia de pão integral",
        "1 fruta + 1 iogurte proteico",
      ],
      completed: false,
      image: "/images/breakfast.jpg",
    },
    almoco: {
      title: "Almoço",
      time: "13:00",
      items: [
        "150g de frango grelhado",
        "1 xícara de arroz integral",
        "Salada à vontade",
      ],
      completed: false,
      image: "/images/lunch.jpg",
    },
    lancheTarde: {
      title: "Lanche da Tarde",
      time: "16:00",
      items: ["Mix de oleaginosas (30g)", "1 fruta"],
      completed: false,
      image: "/images/snack.jpg",
    },
    jantar: {
      title: "Jantar",
      time: "19:00",
      items: ["150g de peixe", "Legumes no vapor", "Batata doce"],
      completed: false,
      image: "/images/dinner.jpg",
    },
  });
  const [showAssistant, setShowAssistant] = useState(true);
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState("");
  const [showChat, setShowChat] = useState(false);
  const [sidebarVisible, setSidebarVisible] = useState(true);
  const [isListening, setIsListening] = useState(false);
  const [progressData, setProgressData] = useState({
    labels: ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun"],
    datasets: [
      {
        label: "Treinos Completados",
        data: [12, 15, 14, 16, 18, 20],
        borderColor: "#ff9933",
        backgroundColor: "rgba(255, 153, 51, 0.2)",
        tension: 0.4,
      },
      {
        label: "Peso Levantado (kg)",
        data: [150, 180, 200, 220, 240, 260],
        borderColor: "#4CAF50",
        backgroundColor: "rgba(76, 175, 80, 0.2)",
        tension: 0.4,
      },
      {
        label: "Calorias Queimadas",
        data: [2000, 2200, 2400, 2600, 2800, 3000],
        borderColor: "#f44336",
        backgroundColor: "rgba(244, 67, 54, 0.2)",
        tension: 0.4,
      },
      {
        label: "Duração dos Treinos (min)",
        data: [45, 50, 55, 60, 65, 70],
        borderColor: "#2196F3",
        backgroundColor: "rgba(33, 150, 243, 0.2)",
        tension: 0.4,
      },
    ],
  });
  const [selectedMusic, setSelectedMusic] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.5);
  const [audioElement, setAudioElement] = useState(null);
  const musicList = [
    {
      id: 1,
      title: "Motivação Intensa",
      duration: "3:45",
      url: "https://example.com/music/motivacao-1.mp3",
    },
    {
      id: 2,
      title: "Energia Máxima",
      duration: "4:20",
      url: "https://example.com/music/energia-2.mp3",
    },
    {
      id: 3,
      title: "Foco Total",
      duration: "3:15",
      url: "https://example.com/music/foco-3.mp3",
    },
    {
      id: 4,
      title: "Power Up",
      duration: "3:30",
      url: "https://example.com/music/power-4.mp3",
    },
    {
      id: 5,
      title: "Beast Mode",
      duration: "4:00",
      url: "https://example.com/music/beast-5.mp3",
    },
    {
      id: 6,
      title: "No Pain No Gain",
      duration: "3:55",
      url: "https://example.com/music/pain-6.mp3",
    },
    {
      id: 7,
      title: "Workout King",
      duration: "4:10",
      url: "https://example.com/music/king-7.mp3",
    },
    {
      id: 8,
      title: "Iron Paradise",
      duration: "3:40",
      url: "https://example.com/music/iron-8.mp3",
    },
    {
      id: 9,
      title: "Pump It Up",
      duration: "3:25",
      url: "https://example.com/music/pump-9.mp3",
    },
    {
      id: 10,
      title: "Warrior Spirit",
      duration: "4:15",
      url: "https://example.com/music/warrior-10.mp3",
    },
    {
      id: 11,
      title: "Gym Time",
      duration: "3:50",
      url: "https://example.com/music/gym-11.mp3",
    },
    {
      id: 12,
      title: "Heavy Lifter",
      duration: "4:05",
      url: "https://example.com/music/heavy-12.mp3",
    },
    {
      id: 13,
      title: "Strength & Power",
      duration: "3:35",
      url: "https://example.com/music/strength-13.mp3",
    },
    {
      id: 14,
      title: "Workout Flow",
      duration: "4:25",
      url: "https://example.com/music/flow-14.mp3",
    },
    {
      id: 15,
      title: "Muscle Up",
      duration: "3:45",
      url: "https://example.com/music/muscle-15.mp3",
    },
    {
      id: 16,
      title: "Training Day",
      duration: "4:00",
      url: "https://example.com/music/training-16.mp3",
    },
    {
      id: 17,
      title: "Fitness Zone",
      duration: "3:30",
      url: "https://example.com/music/fitness-17.mp3",
    },
    {
      id: 18,
      title: "Gym Warrior",
      duration: "4:20",
      url: "https://example.com/music/warrior-18.mp3",
    },
    {
      id: 19,
      title: "Power Hour",
      duration: "3:55",
      url: "https://example.com/music/power-19.mp3",
    },
    {
      id: 20,
      title: "Ultimate Workout",
      duration: "4:15",
      url: "https://example.com/music/ultimate-20.mp3",
    },
    {
      id: 21,
      title: "Gym Beast",
      duration: "3:40",
      url: "https://example.com/music/beast-21.mp3",
    },
    {
      id: 22,
      title: "Training Mode",
      duration: "4:10",
      url: "https://example.com/music/mode-22.mp3",
    },
    {
      id: 23,
      title: "Workout Master",
      duration: "3:50",
      url: "https://example.com/music/master-23.mp3",
    },
  ];
  const [scanning, setScanning] = useState(false);
  const [scannedProduct, setScannedProduct] = useState(null);
  const [upload, { loading }] = useUpload();
  const [error, setError] = useState(null);

  useEffect(() => {
    let interval;
    if (isRunning) {
      interval = setInterval(() => {
        setTime((prevTime) => prevTime + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning]);

  useEffect(() => {
    if ("webkitSpeechRecognition" in window) {
      const recognition = new window.webkitSpeechRecognition();
      recognition.continuous = false;
      recognition.lang = "pt-BR";

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript.toLowerCase();
        if (transcript.includes("jesper me fale sobre treinos")) {
          const response =
            "Aqui estão algumas dicas importantes sobre treinos: 1. Mantenha uma rotina consistente 2. Faça aquecimento antes dos exercícios 3. Foque na técnica correta 4. Aumente as cargas progressivamente 5. Descanse adequadamente entre as séries 6. Mantenha uma alimentação balanceada 7. Hidrate-se bem durante o treino 💪";
          setMessages((prev) => [
            ...prev,
            { sender: "user", text: transcript },
            { sender: "jesper", text: response },
          ]);
          setShowChat(true);
        }
      };

      window.recognition = recognition;
    }
  }, []);

  useEffect(() => {
    if (selectedMusic) {
      if (!audioElement) {
        const audio = new Audio(selectedMusic.url);
        setAudioElement(audio);
      } else {
        audioElement.src = selectedMusic.url;
      }
    }
  }, [selectedMusic]);

  useEffect(() => {
    if (audioElement) {
      if (isPlaying) {
        audioElement.play();
      } else {
        audioElement.pause();
      }
    }
  }, [isPlaying, audioElement]);

  useEffect(() => {
    if (audioElement) {
      audioElement.volume = volume;
    }
  }, [volume, audioElement]);

  useEffect(() => {
    const ctx = document.getElementById("progressChart")?.getContext("2d");
    if (ctx) {
      new Chart(ctx, {
        type: "line",
        data: progressData,
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            y: {
              beginAtZero: true,
              grid: {
                color: "rgba(255, 255, 255, 0.1)",
              },
              ticks: {
                color: "#fff",
              },
            },
            x: {
              grid: {
                color: "rgba(255, 255, 255, 0.1)",
              },
              ticks: {
                color: "#fff",
              },
            },
          },
          plugins: {
            legend: {
              labels: {
                color: "#fff",
              },
            },
            tooltip: {
              backgroundColor: "rgba(0, 0, 0, 0.8)",
              titleColor: "#fff",
              bodyColor: "#fff",
              borderColor: "#ff9933",
              borderWidth: 1,
              padding: 10,
            },
          },
        },
      });
    }
  }, [progressData]);

  const startListening = () => {
    if (window.recognition) {
      window.recognition.start();
    }
  };
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs
      .toString()
      .padStart(2, "0")}`;
  };
  const handleTabClick = (tab) => {
    setActiveTab(tab);
    const menuItems = document.querySelectorAll(".menu-item");
    menuItems.forEach((item) => {
      if (item.getAttribute("data-tab") === tab) {
        item.classList.add("bg-[#4d4d4d]");
      } else {
        item.classList.remove("bg-[#4d4d4d]");
      }
    });
  };
  const handleScan = async (file) => {
    if (!file) return;

    try {
      const { url, error } = await upload({ file });
      if (error) {
        setError(error);
        return;
      }

      setScannedProduct({
        name: "Whey Protein Isolado",
        brand: "Growth",
        calories: "120",
        protein: "27g",
        carbs: "3g",
        fat: "0.3g",
      });

      setScanning(false);
    } catch (err) {
      setError("Erro ao escanear produto");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1a1a1a] to-[#2d2d2d] text-white font-roboto relative overflow-x-hidden">
      <div className="fixed bottom-0 left-0 right-0 bg-[#2a2a2a] border-t border-[#3d3d3d] p-4 z-50">
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-4 flex-1">
            <button
              onClick={() => {
                if (selectedMusic) {
                  setIsPlaying(!isPlaying);
                }
              }}
              className={`p-2 rounded-full ${
                selectedMusic
                  ? "bg-[#ff9933] hover:bg-[#ff8000]"
                  : "bg-[#3d3d3d] cursor-not-allowed"
              }`}
              disabled={!selectedMusic}
            >
              <i className={`fas ${isPlaying ? "fa-pause" : "fa-play"}`}></i>
            </button>
            <div className="flex-1">
              <select
                value={selectedMusic?.id || ""}
                onChange={(e) => {
                  const music = musicList.find(
                    (m) => m.id === Number(e.target.value)
                  );
                  setSelectedMusic(music);
                  setIsPlaying(true);
                }}
                className="w-full bg-[#3d3d3d] rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#ff9933]"
              >
                <option value="">Selecione uma música</option>
                {musicList.map((music) => (
                  <option key={music.id} value={music.id}>
                    {music.title} - {music.duration}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <i className="fas fa-volume-down"></i>
            <input
              type="range"
              min="0"
              max="1"
              step="0.1"
              value={volume}
              onChange={(e) => setVolume(Number(e.target.value))}
              className="w-24 accent-[#ff9933]"
            />
            <i className="fas fa-volume-up"></i>
          </div>
        </div>
      </div>
      <div
        className={`fixed top-0 left-0 w-full h-full z-40 bg-[#1a1a1a] transition-opacity duration-300 ${
          sidebarVisible
            ? "opacity-70 md:opacity-0"
            : "opacity-0 pointer-events-none"
        }`}
        onClick={() => setSidebarVisible(false)}
      ></div>
      <button
        onClick={() => setSidebarVisible(!sidebarVisible)}
        className={`fixed top-4 left-4 z-50 bg-[#3d3d3d] p-2 rounded-full hover:bg-[#4d4d4d] transition-all duration-300 ${
          sidebarVisible
            ? "translate-x-[16rem] md:translate-x-60"
            : "translate-x-0"
        }`}
      >
        <i className={`fas ${sidebarVisible ? "fa-times" : "fa-bars"}`}></i>
      </button>
      <div
        className={`fixed top-0 left-0 h-full w-64 max-w-[80vw] bg-[#2a2a2a] z-50 transform transition-transform duration-300 ease-in-out ${
          sidebarVisible ? "translate-x-0" : "-translate-x-full"
        } shadow-lg`}
      >
        <div className="p-4 flex flex-col gap-4 border-r border-[#3d3d3d] h-full overflow-y-auto">
          <div className="flex flex-col items-center text-center">
            {editingProfile ? (
              <div className="space-y-4 w-full">
                <div className="w-32 h-32 rounded-full overflow-hidden mb-4 mx-auto relative">
                  <img
                    src={profile.photo}
                    alt="Foto de perfil"
                    className="w-full h-full object-cover"
                  />
                  <label className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white text-xs py-1 cursor-pointer text-center">
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        if (e.target.files && e.target.files[0]) {
                          setProfile((prev) => ({
                            ...prev,
                            photo: URL.createObjectURL(e.target.files[0]),
                          }));
                        }
                      }}
                    />
                    Alterar foto
                  </label>
                </div>
                <input
                  type="text"
                  value={profile.name}
                  onChange={(e) =>
                    setProfile((prev) => ({ ...prev, name: e.target.value }))
                  }
                  className="bg-[#3d3d3d] px-3 py-2 rounded w-full text-center"
                />
                <input
                  type="number"
                  value={profile.age}
                  onChange={(e) =>
                    setProfile((prev) => ({ ...prev, age: e.target.value }))
                  }
                  className="bg-[#3d3d3d] px-3 py-2 rounded w-full text-center"
                  placeholder="Idade"
                />
                <input
                  type="number"
                  value={profile.height}
                  onChange={(e) =>
                    setProfile((prev) => ({ ...prev, height: e.target.value }))
                  }
                  className="bg-[#3d3d3d] px-3 py-2 rounded w-full text-center"
                  placeholder="Altura (cm)"
                />
                <input
                  type="number"
                  value={profile.weight}
                  onChange={(e) =>
                    setProfile((prev) => ({ ...prev, weight: e.target.value }))
                  }
                  className="bg-[#3d3d3d] px-3 py-2 rounded w-full text-center"
                  placeholder="Peso (kg)"
                />
                <button
                  onClick={() => setEditingProfile(false)}
                  className="bg-[#ff9933] px-4 py-2 rounded w-full hover:bg-[#ff8000] transition-colors"
                >
                  Salvar
                </button>
              </div>
            ) : (
              <>
                <div className="w-32 h-32 rounded-full overflow-hidden mb-4 relative group">
                  <img
                    src={profile.photo}
                    alt="Foto de perfil"
                    className="w-full h-full object-cover"
                  />
                </div>
                <h2 className="text-xl font-bold mb-1">{profile.name}</h2>
                <p className="text-gray-400 text-sm mb-4">{profile.goal}</p>
                <div className="w-full space-y-2">
                  <div className="bg-[#3d3d3d] p-2 rounded">
                    <p className="text-sm">Idade: {profile.age} anos</p>
                  </div>
                  <div className="bg-[#3d3d3d] p-2 rounded">
                    <p className="text-sm">Altura: {profile.height} cm</p>
                  </div>
                  <div className="bg-[#3d3d3d] p-2 rounded">
                    <p className="text-sm">Peso: {profile.weight} kg</p>
                  </div>
                  <div className="bg-[#3d3d3d] p-2 rounded">
                    <p className="text-sm">Nível: {profile.level}</p>
                  </div>
                  <button
                    onClick={() => setEditingProfile(true)}
                    className="bg-[#ff9933] px-4 py-2 rounded w-full hover:bg-[#ff8000] transition-colors"
                  >
                    Editar Perfil
                  </button>
                </div>
              </>
            )}
          </div>
          <div className="border-t border-[#3d3d3d] pt-4">
            <nav className="space-y-2">
              <a
                href="#"
                onClick={() => handleTabClick("workout")}
                data-tab="workout"
                className="menu-item block bg-[#3d3d3d] p-2 rounded text-sm hover:bg-[#4d4d4d]"
              >
                <i className="fas fa-dumbbell mr-2"></i>Meus Treinos
              </a>
              <a
                href="#"
                onClick={() => handleTabClick("nutrition")}
                data-tab="nutrition"
                className="menu-item block bg-[#3d3d3d] p-2 rounded text-sm hover:bg-[#4d4d4d]"
              >
                <i className="fas fa-utensils mr-2"></i>Plano Alimentar
              </a>
              <a
                href="#"
                onClick={() => handleTabClick("fasting")}
                data-tab="fasting"
                className="menu-item block bg-[#3d3d3d] p-2 rounded text-sm hover:bg-[#4d4d4d]"
              >
                <i className="fas fa-clock mr-2"></i>Jejum
              </a>
              <a
                href="#"
                onClick={() => handleTabClick("dopamine")}
                data-tab="dopamine"
                className="menu-item block bg-[#3d3d3d] p-2 rounded text-sm hover:bg-[#4d4d4d]"
              >
                <i className="fas fa-brain mr-2"></i>Dopamina
              </a>
              <a
                href="#"
                onClick={() => handleTabClick("progress")}
                data-tab="progress"
                className="menu-item block bg-[#3d3d3d] p-2 rounded text-sm hover:bg-[#4d4d4d]"
              >
                <i className="fas fa-chart-line mr-2"></i>Progresso
              </a>
              <a
                href="#"
                onClick={() => handleTabClick("measurements")}
                data-tab="measurements"
                className="menu-item block bg-[#3d3d3d] p-2 rounded text-sm hover:bg-[#4d4d4d]"
              >
                <i className="fas fa-weight mr-2"></i>Medidas
              </a>
            </nav>
          </div>
        </div>
      </div>

      <div
        className={`w-full transition-all duration-300 ${
          sidebarVisible ? "md:ml-64" : "ml-0"
        }`}
      >
        <div className="p-4 relative max-w-full overflow-x-hidden pb-20">
          <button
            onClick={() => {
              setShowChat(true);
              setShowAssistant(false);
            }}
            className="fixed top-4 right-4 z-50 bg-[#3d3d3d] p-3 rounded-full hover:bg-[#4d4d4d] transition-colors"
          >
            <i className="fas fa-robot text-[#ff9933]"></i>
          </button>
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-4">
              <div className="flex items-center bg-[#1a1a1a]/80 p-6 rounded-2xl shadow-lg backdrop-blur-lg">
                <h1 className="text-6xl font-bold tracking-wider bg-gradient-to-r from-[#ff4d4d] via-[#ff9933] to-[#ffcc00] text-transparent bg-clip-text">
                  JESPER
                </h1>
                <i className="fas fa-dumbbell text-[#ff9933] text-4xl ml-3 animate-bounce"></i>
              </div>
            </div>
            <p className="text-gray-300 mt-4 text-lg font-light tracking-wide">
              Seu assistente pessoal de treino e nutrição
            </p>
          </div>

          <div className="max-w-4xl mx-auto backdrop-blur-lg bg-[#1a1a1a]/60 rounded-xl shadow-2xl p-6 overflow-x-hidden">
            <div className="flex flex-wrap gap-2 mb-6 bg-[#2a2a2a]/50 p-2 rounded-lg backdrop-blur-sm">
              <button
                onClick={() => handleTabClick("workout")}
                className={`px-6 py-3 rounded-lg transition-all duration-300 flex-1 min-w-[120px] ${
                  activeTab === "workout"
                    ? "bg-gradient-to-r from-[#ff4d4d] to-[#ff9933] text-white shadow-lg"
                    : "bg-[#2a2a2a] hover:bg-[#3d3d3d]"
                }`}
              >
                <i className="fas fa-dumbbell mr-2"></i>Treino
              </button>
              <button
                onClick={() => handleTabClick("nutrition")}
                className={`px-6 py-3 rounded-lg transition-all duration-300 flex-1 min-w-[120px] ${
                  activeTab === "nutrition"
                    ? "bg-gradient-to-r from-[#ff4d4d] to-[#ff9933] text-white shadow-lg"
                    : "bg-[#2a2a2a] hover:bg-[#3d3d3d]"
                }`}
              >
                <i className="fas fa-utensils mr-2"></i>Nutrição
              </button>
              <button
                onClick={() => handleTabClick("fasting")}
                className={`px-6 py-3 rounded-lg transition-all duration-300 flex-1 min-w-[120px] ${
                  activeTab === "fasting"
                    ? "bg-gradient-to-r from-[#ff4d4d] to-[#ff9933] text-white shadow-lg"
                    : "bg-[#2a2a2a] hover:bg-[#3d3d3d]"
                }`}
              >
                <i className="fas fa-clock mr-2"></i>Jejum
              </button>
              <button
                onClick={() => handleTabClick("dopamine")}
                className={`px-6 py-3 rounded-lg transition-all duration-300 flex-1 min-w-[120px] ${
                  activeTab === "dopamine"
                    ? "bg-gradient-to-r from-[#ff4d4d] to-[#ff9933] text-white shadow-lg"
                    : "bg-[#2a2a2a] hover:bg-[#3d3d3d]"
                }`}
              >
                <i className="fas fa-brain mr-2"></i>Dopamina
              </button>
              <button
                onClick={() => handleTabClick("measurements")}
                className={`px-6 py-3 rounded-lg transition-all duration-300 flex-1 min-w-[120px] ${
                  activeTab === "measurements"
                    ? "bg-gradient-to-r from-[#ff4d4d] to-[#ff9933] text-white shadow-lg"
                    : "bg-[#2a2a2a] hover:bg-[#3d3d3d]"
                }`}
              >
                <i className="fas fa-weight mr-2"></i>Medidas
              </button>
              <button
                onClick={() => handleTabClick("progress")}
                className={`px-6 py-3 rounded-lg transition-all duration-300 flex-1 min-w-[120px] ${
                  activeTab === "progress"
                    ? "bg-gradient-to-r from-[#ff4d4d] to-[#ff9933] text-white shadow-lg"
                    : "bg-[#2a2a2a] hover:bg-[#3d3d3d]"
                }`}
              >
                <i className="fas fa-chart-line mr-2"></i>Progresso
              </button>
            </div>

            {activeTab === "nutrition" && (
              <div className="bg-[#2a2a2a] p-6 rounded-lg">
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-4">
                    Scanner de Produtos
                  </h3>
                  <div className="bg-[#3d3d3d] p-4 rounded-lg">
                    <div className="flex flex-col items-center gap-4">
                      <input
                        type="file"
                        accept="image/*"
                        capture="environment"
                        onChange={(e) => {
                          if (e.target.files) {
                            handleScan(e.target.files[0]);
                          }
                        }}
                        className="hidden"
                        id="scanner"
                      />
                      <label
                        htmlFor="scanner"
                        className="bg-[#ff9933] px-6 py-3 rounded-lg cursor-pointer hover:bg-[#ff8000] transition-colors flex items-center gap-2"
                      >
                        <i className="fas fa-camera"></i>
                        Escanear Produto
                      </label>
                      {error && (
                        <div className="text-red-500 text-sm">{error}</div>
                      )}
                      {loading && (
                        <div className="text-[#ff9933]">Escaneando...</div>
                      )}
                      {scannedProduct && (
                        <div className="w-full bg-[#2a2a2a] p-4 rounded-lg">
                          <h4 className="font-bold mb-2 text-lg">
                            {scannedProduct.name}
                          </h4>
                          <p className="text-gray-400 text-sm mb-4">
                            {scannedProduct.brand}
                          </p>
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <p className="text-sm text-gray-400">Calorias</p>
                              <p>{scannedProduct.calories}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-400">Proteínas</p>
                              <p>{scannedProduct.protein}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-400">
                                Carboidratos
                              </p>
                              <p>{scannedProduct.carbs}</p>
                            </div>
                            <div>
                              <p className="text-sm text-gray-400">Gorduras</p>
                              <p>{scannedProduct.fat}</p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <div className="bg-[#2a2a2a] p-6 rounded-lg">
                  <h3 className="text-xl font-bold mb-4">Plano Alimentar</h3>
                  <div className="space-y-6">
                    {Object.entries(meals).map(([key, meal]) => (
                      <div key={key} className="bg-[#3d3d3d] p-4 rounded">
                        {editingMeal === key ? (
                          <div className="space-y-4">
                            <input
                              type="text"
                              value={meal.title}
                              onChange={(e) =>
                                setMeals((prev) => ({
                                  ...prev,
                                  [key]: {
                                    ...prev[key],
                                    title: e.target.value,
                                  },
                                }))
                              }
                              className="bg-[#2a2a2a] px-2 py-1 rounded w-full"
                            />
                            <div>
                              <label className="block text-sm mb-1">
                                Horário
                              </label>
                              <input
                                type="text"
                                value={meal.time}
                                onChange={(e) =>
                                  setMeals((prev) => ({
                                    ...prev,
                                    [key]: {
                                      ...prev[key],
                                      time: e.target.value,
                                    },
                                  }))
                                }
                                className="bg-[#2a2a2a] px-2 py-1 rounded w-full"
                              />
                            </div>
                            <div>
                              <label className="block text-sm mb-1">
                                Itens
                              </label>
                              {meal.items.map((item, index) => (
                                <div key={index} className="flex gap-2 mb-2">
                                  <input
                                    type="text"
                                    value={item}
                                    onChange={(e) => {
                                      const newItems = [...meal.items];
                                      newItems[index] = e.target.value;
                                      setMeals((prev) => ({
                                        ...prev,
                                        [key]: {
                                          ...prev[key],
                                          items: newItems,
                                        },
                                      }));
                                    }}
                                    className="bg-[#2a2a2a] px-2 py-1 rounded flex-1"
                                  />
                                  <button
                                    onClick={() => {
                                      const newItems = meal.items.filter(
                                        (_, i) => i !== index
                                      );
                                      setMeals((prev) => ({
                                        ...prev,
                                        [key]: {
                                          ...prev[key],
                                          items: newItems,
                                        },
                                      }));
                                    }}
                                    className="bg-[#2a2a2a] px-2 py-1 rounded"
                                  >
                                    <i className="fas fa-trash"></i>
                                  </button>
                                </div>
                              ))}
                              <button
                                onClick={() => {
                                  setMeals((prev) => ({
                                    ...prev,
                                    [key]: {
                                      ...prev[key],
                                      items: [...prev[key].items, ""],
                                    },
                                  }));
                                }}
                                className="bg-[#2a2a2a] px-4 py-2 rounded mt-2"
                              >
                                Adicionar Item
                              </button>
                            </div>
                            <button
                              onClick={() => setEditingMeal(null)}
                              className="bg-[#2a2a2a] px-4 py-2 rounded mt-2"
                            >
                              Salvar
                            </button>
                          </div>
                        ) : (
                          <>
                            <div className="flex justify-between items-center mb-4">
                              <h4 className="font-bold text-lg">
                                {meal.title}
                              </h4>
                              <button
                                onClick={() => setEditingMeal(key)}
                                className="text-sm bg-[#2a2a2a] px-2 py-1 rounded"
                              >
                                Editar
                              </button>
                            </div>
                            <div className="flex flex-col md:flex-row gap-6">
                              <div className="w-full md:w-1/3">
                                <img
                                  src={meal.image}
                                  alt={`Imagem ilustrativa de ${meal.title.toLowerCase()}`}
                                  className="w-full h-[200px] object-cover rounded-lg"
                                />
                              </div>
                              <div className="flex-1">
                                {meal.items.map((item, index) => (
                                  <p key={index} className="mb-2">
                                    • {item}
                                  </p>
                                ))}
                                <p className="text-sm text-gray-400 mt-4">
                                  Horário recomendado: {meal.time}
                                </p>
                              </div>
                            </div>
                          </>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === "workout" && (
              <>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-6">
                  {Object.keys(workouts).map((workout) => (
                    <button
                      key={workout}
                      onClick={() => setSelectedWorkout(workout)}
                      className={`p-4 rounded ${
                        selectedWorkout === workout
                          ? "bg-[#3d3d3d]"
                          : "bg-[#2a2a2a]"
                      }`}
                    >
                      Treino {workout}
                    </button>
                  ))}
                </div>
                <div className="bg-[#2a2a2a] p-4 md:p-6 rounded-lg mb-6">
                  <div className="flex flex-col md:flex-row justify-between items-center mb-4 gap-4">
                    <h3 className="text-xl font-bold">Cronômetro</h3>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setIsRunning(!isRunning)}
                        className="bg-[#3d3d3d] px-4 py-2 rounded"
                      >
                        {isRunning ? "Pausar" : "Iniciar"}
                      </button>
                      <button
                        onClick={() => {
                          setTime(0);
                          setIsRunning(false);
                        }}
                        className="bg-[#3d3d3d] px-4 py-2 rounded"
                      >
                        Zerar
                      </button>
                    </div>
                  </div>
                  <div className="text-3xl font-bold mb-2 text-center md:text-left">
                    {formatTime(time)}
                  </div>
                  {selectedWorkout === "D" && (
                    <div className="flex items-center space-x-2">
                      <span>Distância:</span>
                      <input
                        type="number"
                        value={distance}
                        onChange={(e) => setDistance(e.target.value)}
                        className="bg-[#3d3d3d] px-2 py-1 rounded w-20"
                      />
                      <span>km</span>
                    </div>
                  )}
                </div>
                <div className="bg-[#2a2a2a] p-4 md:p-6 rounded-lg">
                  <h3 className="text-xl font-bold mb-4">
                    Exercícios - Treino {selectedWorkout}
                  </h3>
                  <div className="space-y-4">
                    {workouts[selectedWorkout].map((exercise, index) => (
                      <div key={index} className="bg-[#3d3d3d] p-4 rounded">
                        {editingExercise === index ? (
                          <div className="space-y-2">
                            <input
                              type="text"
                              value={exercise.exercise}
                              onChange={(e) => {
                                const newWorkouts = { ...workouts };
                                newWorkouts[selectedWorkout][index].exercise =
                                  e.target.value;
                                setWorkouts(newWorkouts);
                              }}
                              className="bg-[#2a2a2a] px-2 py-1 rounded w-full"
                            />
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                              <input
                                type="number"
                                value={exercise.sets}
                                onChange={(e) => {
                                  const newWorkouts = { ...workouts };
                                  newWorkouts[selectedWorkout][index].sets =
                                    e.target.value;
                                  setWorkouts(newWorkouts);
                                }}
                                className="bg-[#2a2a2a] px-2 py-1 rounded"
                                placeholder="Séries"
                              />
                              <input
                                type="text"
                                value={exercise.reps}
                                onChange={(e) => {
                                  const newWorkouts = { ...workouts };
                                  newWorkouts[selectedWorkout][index].reps =
                                    e.target.value;
                                  setWorkouts(newWorkouts);
                                }}
                                className="bg-[#2a2a2a] px-2 py-1 rounded"
                                placeholder="Repetições"
                              />
                              <input
                                type="number"
                                value={exercise.weight}
                                onChange={(e) => {
                                  const newWorkouts = { ...workouts };
                                  newWorkouts[selectedWorkout][index].weight =
                                    e.target.value;
                                  setWorkouts(newWorkouts);
                                }}
                                className="bg-[#2a2a2a] px-2 py-1 rounded"
                                placeholder="Peso (kg)"
                              />
                            </div>
                            <button
                              onClick={() => setEditingExercise(null)}
                              className="bg-[#2a2a2a] px-4 py-2 rounded mt-2 w-full md:w-auto"
                            >
                              Salvar
                            </button>
                          </div>
                        ) : (
                          <>
                            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-2 gap-2">
                              <h4 className="font-bold">{exercise.exercise}</h4>
                              <button
                                onClick={() => setEditingExercise(index)}
                                className="text-sm bg-[#2a2a2a] px-2 py-1 rounded"
                              >
                                Editar
                              </button>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                              <div>
                                <span className="text-sm">
                                  Séries: {exercise.sets}
                                </span>
                              </div>
                              <div>
                                <span className="text-sm">
                                  Reps: {exercise.reps}
                                </span>
                              </div>
                              <div>
                                <input
                                  type="number"
                                  placeholder="Peso (kg)"
                                  value={exercise.weight}
                                  onChange={(e) => {
                                    const newWorkouts = { ...workouts };
                                    newWorkouts[selectedWorkout][index].weight =
                                      e.target.value;
                                    setWorkouts(newWorkouts);
                                  }}
                                  className="bg-[#2a2a2a] px-2 py-1 rounded w-full"
                                />
                              </div>
                            </div>
                          </>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}

            {activeTab === "measurements" && (
              <div className="bg-[#2a2a2a] p-6 rounded-lg">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-xl font-bold">Avaliação Física</h3>
                  <button
                    onClick={() => {
                      const newMeasurements = {
                        peso: measurements.peso || "",
                        altura: measurements.altura || "",
                        gordura: measurements.gordura || "",
                        muscular: measurements.muscular || "",
                      };
                      setMeasurements(newMeasurements);
                    }}
                    className="bg-[#3d3d3d] px-4 py-2 rounded"
                  >
                    Salvar Medidas
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm mb-1">Peso (kg)</label>
                    <input
                      type="number"
                      value={measurements.peso}
                      onChange={(e) =>
                        setMeasurements((prev) => ({
                          ...prev,
                          peso: e.target.value,
                        }))
                      }
                      className="bg-[#3d3d3d] px-3 py-2 rounded w-full"
                    />
                  </div>
                  <div>
                    <label className="block text-sm mb-1">Altura (cm)</label>
                    <input
                      type="number"
                      value={measurements.altura}
                      onChange={(e) =>
                        setMeasurements((prev) => ({
                          ...prev,
                          altura: e.target.value,
                        }))
                      }
                      className="bg-[#3d3d3d] px-3 py-2 rounded w-full"
                    />
                  </div>
                  <div>
                    <label className="block text-sm mb-1">% Gordura</label>
                    <input
                      type="number"
                      value={measurements.gordura}
                      onChange={(e) =>
                        setMeasurements((prev) => ({
                          ...prev,
                          gordura: e.target.value,
                        }))
                      }
                      className="bg-[#3d3d3d] px-3 py-2 rounded w-full"
                    />
                  </div>
                  <div>
                    <label className="block text-sm mb-1">
                      % Massa Muscular
                    </label>
                    <input
                      type="number"
                      value={measurements.muscular}
                      onChange={(e) =>
                        setMeasurements((prev) => ({
                          ...prev,
                          muscular: e.target.value,
                        }))
                      }
                      className="bg-[#3d3d3d] px-3 py-2 rounded w-full"
                    />
                  </div>
                </div>
              </div>
            )}

            {activeTab === "progress" && (
              <div className="bg-[#2a2a2a] p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-4">
                  Progresso dos Treinos
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-[#3d3d3d] rounded-lg p-4">
                    <h4 className="text-lg font-semibold mb-3">
                      Gráfico de Progresso
                    </h4>
                    <div className="w-full h-[400px]">
                      <canvas id="progressChart"></canvas>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-4">
                      {progressData.datasets.map((dataset, index) => (
                        <div
                          key={index}
                          className="flex items-center gap-2 text-sm"
                          style={{ color: dataset.borderColor }}
                        >
                          <div
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: dataset.borderColor }}
                          ></div>
                          <span>{dataset.label}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="bg-[#3d3d3d] rounded-lg p-4">
                    <h4 className="text-lg font-semibold mb-3">
                      Estatísticas do Mês
                    </h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-[#2a2a2a] p-4 rounded-lg">
                        <div className="text-[#ff9933] text-2xl font-bold">
                          20
                        </div>
                        <div className="text-sm text-gray-400">
                          Treinos Realizados
                        </div>
                      </div>
                      <div className="bg-[#2a2a2a] p-4 rounded-lg">
                        <div className="text-[#4CAF50] text-2xl font-bold">
                          260kg
                        </div>
                        <div className="text-sm text-gray-400">Peso Máximo</div>
                      </div>
                      <div className="bg-[#2a2a2a] p-4 rounded-lg">
                        <div className="text-[#f44336] text-2xl font-bold">
                          3000
                        </div>
                        <div className="text-sm text-gray-400">
                          Calorias/Treino
                        </div>
                      </div>
                      <div className="bg-[#2a2a2a] p-4 rounded-lg">
                        <div className="text-[#2196F3] text-2xl font-bold">
                          70min
                        </div>
                        <div className="text-sm text-gray-400">Tempo Médio</div>
                      </div>
                    </div>
                  </div>
                  <div className="bg-[#3d3d3d] rounded-lg p-4 md:col-span-2">
                    <h4 className="text-lg font-semibold mb-3">
                      Histórico de Treinos
                    </h4>
                    <div className="space-y-2">
                      {[
                        "Segunda",
                        "Terça",
                        "Quarta",
                        "Quinta",
                        "Sexta",
                        "Sábado",
                        "Domingo",
                      ].map((day, index) => (
                        <div
                          key={day}
                          className="flex justify-between items-center bg-[#2a2a2a] p-3 rounded"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-2 h-2 rounded-full bg-[#ff9933]"></div>
                            <span className="font-semibold">{day}</span>
                            <span className="text-sm text-gray-400">
                              Treino {String.fromCharCode(65 + (index % 4))}
                            </span>
                          </div>
                          <div className="flex items-center gap-4">
                            <span className="text-sm text-[#4CAF50]">
                              260kg
                            </span>
                            <span className="text-sm text-[#f44336]">
                              500 kcal
                            </span>
                            <span className="text-sm text-[#2196F3]">
                              70min
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "fasting" && (
              <div className="bg-[#2a2a2a] p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-4">Controle de Jejum</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-[#3d3d3d] p-4 rounded-lg">
                    <h4 className="text-lg font-semibold mb-3">Jejum Atual</h4>
                    <div className="text-center">
                      <div className="text-4xl font-bold text-[#ff9933] mb-2">
                        {formatTime(time)}
                      </div>
                      <div className="flex justify-center gap-4 mb-4">
                        <button
                          onClick={() => setIsRunning(!isRunning)}
                          className="bg-[#2a2a2a] px-6 py-2 rounded-lg hover:bg-[#4d4d4d]"
                        >
                          {isRunning ? "Pausar" : "Iniciar"}
                        </button>
                        <button
                          onClick={() => {
                            setTime(0);
                            setIsRunning(false);
                          }}
                          className="bg-[#2a2a2a] px-6 py-2 rounded-lg hover:bg-[#4d4d4d]"
                        >
                          Zerar
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "dopamine" && (
              <div className="bg-[#2a2a2a] p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-4">Detox de Dopamina</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-[#3d3d3d] p-4 rounded-lg">
                    <h4 className="text-lg font-semibold mb-3">
                      Atividades para Evitar
                    </h4>
                    <ul className="space-y-2">
                      <li className="flex items-center gap-2">
                        <i className="fas fa-times text-red-500"></i>
                        Redes Sociais
                      </li>
                      <li className="flex items-center gap-2">
                        <i className="fas fa-times text-red-500"></i>
                        Jogos Eletrônicos
                      </li>
                      <li className="flex items-center gap-2">
                        <i className="fas fa-times text-red-500"></i>
                        Streaming de Vídeos
                      </li>
                    </ul>
                  </div>
                  <div className="bg-[#3d3d3d] p-4 rounded-lg">
                    <h4 className="text-lg font-semibold mb-3">
                      Atividades Recomendadas
                    </h4>
                    <ul className="space-y-2">
                      <li className="flex items-center gap-2">
                        <i className="fas fa-check text-green-500"></i>
                        Leitura
                      </li>
                      <li className="flex items-center gap-2">
                        <i className="fas fa-check text-green-500"></i>
                        Meditação
                      </li>
                      <li className="flex items-center gap-2">
                        <i className="fas fa-check text-green-500"></i>
                        Exercícios Físicos
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </div>

          {showChat && (
            <div className="fixed bottom-4 right-4 bg-[#2a2a2a] p-4 rounded-lg shadow-lg w-[400px] animate-fade-in">
              <div className="flex justify-between items-center mb-3">
                <div className="flex items-center">
                  <i className="fas fa-robot text-[#ff9933] text-xl mr-2"></i>
                  <h3 className="text-lg font-bold">Chat com Jesper</h3>
                </div>
                <button
                  onClick={() => setShowChat(false)}
                  className="text-gray-400 hover:text-white"
                >
                  <i className="fas fa-times"></i>
                </button>
              </div>
              <div className="h-[400px] overflow-y-auto mb-3 p-2">
                {messages.map((message, index) => (
                  <div
                    key={index}
                    className={`mb-2 p-3 rounded-lg ${
                      message.sender === "user"
                        ? "bg-[#3d3d3d] ml-auto max-w-[80%]"
                        : "bg-[#ff9933] mr-auto max-w-[80%]"
                    }`}
                  >
                    <div
                      className={`text-sm ${
                        message.sender === "user" ? "text-right" : "text-left"
                      }`}
                    >
                      {message.text}
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                  className="bg-[#3d3d3d] px-4 py-2 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-[#ff9933]"
                  placeholder="Digite sua mensagem..."
                />
                <button
                  onClick={handleSendMessage}
                  className="bg-[#ff9933] px-4 py-2 rounded-lg hover:bg-[#ff8000] transition-colors"
                >
                  <i className="fas fa-paper-plane"></i>
                </button>
              </div>
            </div>
          )}

          {!showAssistant && !showChat && (
            <button
              onClick={() => setShowChat(true)}
              className="fixed bottom-4 right-4 bg-[#ff9933] p-4 rounded-full shadow-lg hover:bg-[#ff8000] transition-colors"
            >
              <i className="fas fa-comment text-white text-xl"></i>
            </button>
          )}

          <style jsx global>{`
  @keyframes fade-in {
    from {
      opacity: 0;
      transform: translateY(20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
  .animate-fade-in {
    animation: fade-in 0.5s ease-out;
  }
  
  @keyframes gradient {
    0% {
      background-position: 0% 50%;
    }
    50% {
      background-position: 100% 50%;
    }
    100% {
      background-position: 0% 50%;
    }
  }
  
  .bg-gradient-animate {
    background-size: 200% 200%;
    animation: gradient 15s ease infinite;
  }
`}</style>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;